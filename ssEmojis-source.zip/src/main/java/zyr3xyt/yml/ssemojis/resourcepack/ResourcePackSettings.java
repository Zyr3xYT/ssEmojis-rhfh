package zyr3xyt.yml.ssemojis.resourcepack;

import org.jetbrains.annotations.NotNull;

public final class ResourcePackSettings {

    private final boolean enabled;
    private final String url;
    private final String sha1;
    private final boolean force;
    private final String prompt;

    public ResourcePackSettings(boolean enabled, @NotNull String url, @NotNull String sha1, boolean force, @NotNull String prompt) {
        this.enabled = enabled;
        this.url = url;
        this.sha1 = sha1;
        this.force = force;
        this.prompt = prompt;
    }

    public static ResourcePackSettings disabled() {
        return new ResourcePackSettings(false, "", "", false, "");
    }

    public boolean enabled() {
        return enabled;
    }

    @NotNull
    public String url() {
        return url;
    }

    @NotNull
    public String sha1() {
        return sha1;
    }

    public boolean force() {
        return force;
    }

    @NotNull
    public String prompt() {
        return prompt;
    }
}
