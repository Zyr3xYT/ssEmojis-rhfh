package zyr3xyt.yml.ssemojis.config;

import zyr3xyt.yml.ssemojis.resourcepack.ResourcePackSettings;
import zyr3xyt.yml.ssemojis.sprite.Sprite;
import zyr3xyt.yml.ssemojis.sprite.SpriteRegistry;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.jetbrains.annotations.NotNull;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Loads and validates config.yml into an immutable SpriteRegistry.
 */
public final class ConfigManager {

    private final Path dataFolder;
    private final Logger logger;

    public ConfigManager(@NotNull Path dataFolder, @NotNull Logger logger) {
        this.dataFolder = dataFolder;
        this.logger = logger;
    }

    @NotNull
    public SpriteRegistry loadRegistry() throws IOException {
        Path configPath = dataFolder.resolve("config.yml");
        if (!Files.exists(configPath)) {
            throw new IOException("config.yml not found in " + dataFolder);
        }

        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(configPath.toFile());

        String defaultNamespace = yaml.getString("settings.default-namespace", "minecraft")
            .toLowerCase(Locale.ROOT);
        String unknownBehavior = yaml.getString("settings.unknown-sprite-behavior", "keep")
            .toLowerCase(Locale.ROOT);
        boolean colonParser = yaml.getBoolean("settings.enable-colon-parser", true);
        boolean minimessage = yaml.getBoolean("settings.enable-minimessage-tags", true);
        boolean debug = yaml.getBoolean("settings.debug", false);

        boolean rpEnabled = yaml.getBoolean("resource-pack.enabled", true);
        String rpUrl = yaml.getString("resource-pack.url", "");
        String rpSha1 = yaml.getString("resource-pack.sha1", "");
        boolean rpForce = yaml.getBoolean("resource-pack.force", false);
        String rpPrompt = yaml.getString("resource-pack.prompt", "Download the ssEmojis sprite pack");

        ResourcePackSettings rpSettings = new ResourcePackSettings(
            rpEnabled && rpUrl != null && !rpUrl.isBlank(),
            rpUrl == null ? "" : rpUrl.trim(),
            rpSha1 == null ? "" : rpSha1.trim(),
            rpForce,
            rpPrompt == null ? "" : rpPrompt
        );

        Map<String, Sprite> sprites = new LinkedHashMap<>();
        ConfigurationSection section = yaml.getConfigurationSection("sprites");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                String normalized = SpriteRegistry.normalizeId(key, defaultNamespace);
                if (normalized == null) {
                    logger.warning("Skipping invalid sprite id: " + key);
                    continue;
                }
                ConfigurationSection entry = section.getConfigurationSection(key);
                if (entry == null) {
                    logger.warning("Skipping empty sprite entry: " + key);
                    continue;
                }

                String atlas = entry.getString("atlas");
                String spriteName = entry.getString("sprite");
                String glyph = entry.getString("glyph");

                Sprite sprite;
                if (atlas != null && spriteName != null) {
                    sprite = Sprite.ofAtlas(normalized, atlas, spriteName);
                } else if (glyph != null && !glyph.isEmpty()) {
                    sprite = Sprite.ofGlyph(normalized, glyph);
                } else {
                    logger.warning("Sprite " + key + " has neither atlas+sprite nor glyph; skipped");
                    continue;
                }
                sprites.put(normalized, sprite);
            }
        }

        return new SpriteRegistry(
            defaultNamespace,
            unknownBehavior,
            colonParser,
            minimessage,
            debug,
            sprites,
            rpSettings
        );
    }
}
