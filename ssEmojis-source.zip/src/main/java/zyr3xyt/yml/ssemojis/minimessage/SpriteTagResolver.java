package zyr3xyt.yml.ssemojis.minimessage;

import zyr3xyt.yml.ssemojis.sprite.Sprite;
import zyr3xyt.yml.ssemojis.sprite.SpriteManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.Context;
import net.kyori.adventure.text.minimessage.tag.Tag;
import net.kyori.adventure.text.minimessage.tag.resolver.ArgumentQueue;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * MiniMessage tag resolver for &lt;sprite:id&gt; and &lt;sprite:namespace:id&gt;.
 */
public final class SpriteTagResolver implements TagResolver {

    private final SpriteManager spriteManager;

    public SpriteTagResolver(@NotNull SpriteManager spriteManager) {
        this.spriteManager = spriteManager;
    }

    @Override
    public @Nullable Tag resolve(@NotNull String name, @NotNull ArgumentQueue arguments, @NotNull Context ctx) {
        if (!"sprite".equalsIgnoreCase(name)) {
            return null;
        }
        if (!arguments.hasNext()) {
            return null;
        }
        String id = arguments.pop().value();
        Sprite sprite = spriteManager.getSprite(id);
        if (sprite == null) {
            return Tag.selfClosingInserting(Component.text(":" + id + ":"));
        }
        return Tag.selfClosingInserting(sprite.toComponent());
    }

    @Override
    public boolean has(@NotNull String name) {
        return "sprite".equalsIgnoreCase(name);
    }
}
