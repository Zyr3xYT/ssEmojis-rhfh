package zyr3xyt.yml.ssemojis.sprite;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.Style;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Shared shortcode resolver used by chat, MiniMessage, API, and commands.
 * Matches :id: or :namespace:id: while leaving ordinary text (hello:world) untouched.
 */
public final class SpriteParser {

    // Matches :something: where something is a valid-looking id (with optional namespace)
    private static final Pattern SHORTCODE = Pattern.compile(":([a-zA-Z0-9_./-]+(?::[a-zA-Z0-9_./-]+)?):");

    private final SpriteManager spriteManager;

    public SpriteParser(@NotNull SpriteManager spriteManager) {
        this.spriteManager = spriteManager;
    }

    /**
     * Parse a plain string containing shortcodes into an Adventure Component.
     * Surrounding text and ordinary formatting are preserved.
     */
    @NotNull
    public Component parse(@NotNull String input) {
        SpriteRegistry reg = spriteManager.registry();
        if (!reg.colonParserEnabled() || input.isEmpty()) {
            return Component.text(input);
        }

        Matcher matcher = SHORTCODE.matcher(input);
        if (!matcher.find()) {
            return Component.text(input);
        }

        List<Component> parts = new ArrayList<>();
        int last = 0;
        matcher.reset();

        while (matcher.find()) {
            int start = matcher.start();
            int end = matcher.end();
            if (start > last) {
                parts.add(Component.text(input.substring(last, start)));
            }

            String rawId = matcher.group(1);
            Sprite sprite = reg.get(rawId);

            if (sprite != null) {
                parts.add(sprite.toComponent());
                if (reg.debug()) {
                    // logger would be better but keep parser free of side-effects
                }
            } else {
                // Unknown: keep original text by default
                if ("remove".equalsIgnoreCase(reg.unknownBehavior())) {
                    // omit
                } else {
                    parts.add(Component.text(matcher.group(0)));
                }
            }
            last = end;
        }

        if (last < input.length()) {
            parts.add(Component.text(input.substring(last)));
        }

        if (parts.isEmpty()) {
            return Component.empty();
        }
        if (parts.size() == 1) {
            return parts.get(0);
        }

        TextComponent.Builder builder = Component.text();
        for (Component part : parts) {
            builder.append(part);
        }
        return builder.build();
    }

    /**
     * Convenience: parse and return the component with an optional style applied to text parts.
     */
    @NotNull
    public Component parse(@NotNull String input, @NotNull Style style) {
        return parse(input).style(style);
    }
}
