package zyr3xyt.yml.ssemojis.command;

import zyr3xyt.yml.ssemojis.ssEmojis;
import zyr3xyt.yml.ssemojis.sprite.Sprite;
import zyr3xyt.yml.ssemojis.sprite.SpriteManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.stream.Collectors;

public final class ssEmojisCommand implements CommandExecutor, TabCompleter {

    private final ssEmojis plugin;
    private final SpriteManager spriteManager;

    public ssEmojisCommand(@NotNull ssEmojis plugin, @NotNull SpriteManager spriteManager) {
        this.plugin = plugin;
        this.spriteManager = spriteManager;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sendHelp(sender);
            return true;
        }

        String sub = args[0].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "reload" -> {
                if (!sender.hasPermission("ssem.reload")) {
                    sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                    return true;
                }
                try {
                    spriteManager.reload();
                    sender.sendMessage(Component.text("ssEmojis reloaded successfully (" +
                        spriteManager.getSprites().size() + " sprites).", NamedTextColor.GREEN));
                } catch (Exception e) {
                    sender.sendMessage(Component.text("Reload failed: " + e.getMessage(), NamedTextColor.RED));
                }
            }
            case "list" -> {
                if (!sender.hasPermission("ssem.list")) {
                    sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                    return true;
                }
                Collection<Sprite> sprites = spriteManager.getSprites();
                sender.sendMessage(Component.text("Registered sprites (" + sprites.size() + "):", NamedTextColor.GOLD));
                for (Sprite s : sprites) {
                    String type = s.isAtlas() ? "atlas" : (s.isCustomImage() ? "image" : "glyph");
                    sender.sendMessage(Component.text("  • " + s.id() + " [" + type + "]", NamedTextColor.GRAY));
                }
            }
            case "info" -> {
                if (!sender.hasPermission("ssem.list")) {
                    sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                    return true;
                }
                if (args.length < 2) {
                    sender.sendMessage(Component.text("Usage: /ssem info <sprite>", NamedTextColor.RED));
                    return true;
                }
                Sprite s = spriteManager.getSprite(args[1]);
                if (s == null) {
                    sender.sendMessage(Component.text("Unknown sprite: " + args[1], NamedTextColor.RED));
                    return true;
                }
                sender.sendMessage(Component.text("Sprite: " + s.id(), NamedTextColor.GOLD));
                sender.sendMessage(Component.text("  Type: " + (s.isAtlas() ? "atlas" : "glyph"), NamedTextColor.GRAY));
                if (s.atlas() != null) sender.sendMessage(Component.text("  Atlas: " + s.atlas(), NamedTextColor.GRAY));
                if (s.spriteName() != null) sender.sendMessage(Component.text("  Sprite: " + s.spriteName(), NamedTextColor.GRAY));
                if (s.glyph() != null) sender.sendMessage(Component.text("  Glyph: " + s.glyph(), NamedTextColor.GRAY));
            }
            case "test" -> {
                if (!sender.hasPermission("ssem.test")) {
                    sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                    return true;
                }
                if (args.length < 2) {
                    sender.sendMessage(Component.text("Usage: /ssem test <sprite>", NamedTextColor.RED));
                    return true;
                }
                Sprite s = spriteManager.getSprite(args[1]);
                if (s == null) {
                    sender.sendMessage(Component.text("Unknown sprite: " + args[1], NamedTextColor.RED));
                    return true;
                }
                Component preview = Component.text("Preview: ", NamedTextColor.YELLOW)
                    .append(s.toComponent())
                    .append(Component.text("  (:" + s.id() + ":)", NamedTextColor.GRAY));
                sender.sendMessage(preview);
            }
            case "pack" -> {
                if (!sender.hasPermission("ssem.pack")) {
                    sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
                    return true;
                }
                var settings = spriteManager.resourcePackSettings();
                sender.sendMessage(Component.text("Resource pack:", NamedTextColor.GOLD));
                sender.sendMessage(Component.text("  Enabled: " + settings.enabled(), NamedTextColor.GRAY));
                sender.sendMessage(Component.text("  URL: " + (settings.url().isBlank() ? "(none)" : settings.url()), NamedTextColor.GRAY));
                sender.sendMessage(Component.text("  Force: " + settings.force(), NamedTextColor.GRAY));
            }
            case "image" -> handleImage(sender, args);
            default -> sendHelp(sender);
        }
        return true;
    }

    private void handleImage(@NotNull CommandSender sender, @NotNull String[] args) {
        if (!sender.hasPermission("ssem.image")) {
            sender.sendMessage(Component.text("No permission.", NamedTextColor.RED));
            return;
        }
        if (args.length < 2) {
            sender.sendMessage(Component.text("Usage: /ssem image <list|info|reload|remove|test|validate>", NamedTextColor.YELLOW));
            return;
        }
        String sub = args[1].toLowerCase(Locale.ROOT);
        switch (sub) {
            case "list" -> {
                List<Sprite> images = spriteManager.getSprites().stream()
                    .filter(Sprite::isCustomImage)
                    .collect(Collectors.toList());
                sender.sendMessage(Component.text("Custom images (" + images.size() + "):", NamedTextColor.GOLD));
                for (Sprite s : images) {
                    sender.sendMessage(Component.text("  • " + s.id(), NamedTextColor.GRAY));
                }
            }
            case "info", "test", "validate" -> {
                if (args.length < 3) {
                    sender.sendMessage(Component.text("Usage: /ssem image " + sub + " <name>", NamedTextColor.RED));
                    return;
                }
                Sprite s = spriteManager.getSprite(args[2]);
                if (s == null || !s.isCustomImage()) {
                    sender.sendMessage(Component.text("Unknown custom image: " + args[2], NamedTextColor.RED));
                    return;
                }
                if ("test".equals(sub) || "info".equals(sub)) {
                    sender.sendMessage(Component.text("Image: " + s.id() + " → ", NamedTextColor.YELLOW).append(s.toComponent()));
                } else {
                    sender.sendMessage(Component.text("Image " + s.id() + " is registered (glyph-backed).", NamedTextColor.GREEN));
                }
            }
            case "reload" -> {
                try {
                    spriteManager.reload();
                    sender.sendMessage(Component.text("Images / sprites reloaded.", NamedTextColor.GREEN));
                } catch (Exception e) {
                    sender.sendMessage(Component.text("Reload failed: " + e.getMessage(), NamedTextColor.RED));
                }
            }
            case "remove" -> {
                if (args.length < 3) {
                    sender.sendMessage(Component.text("Usage: /ssem image remove <name>", NamedTextColor.RED));
                    return;
                }
                if (spriteManager.unregisterSprite(args[2])) {
                    sender.sendMessage(Component.text("Removed: " + args[2], NamedTextColor.GREEN));
                } else {
                    sender.sendMessage(Component.text("Not found: " + args[2], NamedTextColor.RED));
                }
            }
            default -> sender.sendMessage(Component.text("Unknown image subcommand.", NamedTextColor.RED));
        }
    }

    private void sendHelp(@NotNull CommandSender sender) {
        sender.sendMessage(Component.text("ssEmojis", NamedTextColor.AQUA, TextDecoration.BOLD)
            .append(Component.text(" by zyr3xyt.yml / Shark Studios", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/ssem help", NamedTextColor.YELLOW).append(Component.text(" — this message", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/ssem reload", NamedTextColor.YELLOW).append(Component.text(" — reload config", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/ssem list", NamedTextColor.YELLOW).append(Component.text(" — list sprites", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/ssem info <id>", NamedTextColor.YELLOW).append(Component.text(" — sprite details", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/ssem test <id>", NamedTextColor.YELLOW).append(Component.text(" — preview sprite", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/ssem pack", NamedTextColor.YELLOW).append(Component.text(" — resource pack status", NamedTextColor.GRAY)));
        sender.sendMessage(Component.text("/ssem image ...", NamedTextColor.YELLOW).append(Component.text(" — custom image management", NamedTextColor.GRAY)));
    }

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        if (args.length == 1) {
            return filter(Arrays.asList("help", "reload", "list", "info", "test", "pack", "image"), args[0]);
        }
        if (args.length == 2) {
            if (args[0].equalsIgnoreCase("info") || args[0].equalsIgnoreCase("test")) {
                return filter(spriteManager.getSprites().stream().map(Sprite::id).collect(Collectors.toList()), args[1]);
            }
            if (args[0].equalsIgnoreCase("image")) {
                return filter(Arrays.asList("list", "info", "reload", "remove", "test", "validate"), args[1]);
            }
        }
        if (args.length == 3 && args[0].equalsIgnoreCase("image")) {
            return filter(spriteManager.getSprites().stream()
                .filter(Sprite::isCustomImage)
                .map(Sprite::id)
                .collect(Collectors.toList()), args[2]);
        }
        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        String p = prefix.toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        for (String o : options) {
            if (o.toLowerCase(Locale.ROOT).startsWith(p)) {
                result.add(o);
            }
        }
        return result;
    }
}
