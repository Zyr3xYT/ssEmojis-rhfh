package zyr3xyt.yml.ssemojis.sprite;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.object.ObjectContents;
import net.kyori.adventure.text.object.SpriteObjectContents;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Objects;

/**
 * Immutable representation of a registered sprite / emoji.
 * Supports either a native Minecraft atlas sprite or a private-use glyph.
 */
public final class Sprite {

    private final String id;
    private final @Nullable String atlas;
    private final @Nullable String spriteName;
    private final @Nullable String glyph;
    private final boolean customImage;

    public Sprite(
        @NotNull String id,
        @Nullable String atlas,
        @Nullable String spriteName,
        @Nullable String glyph,
        boolean customImage
    ) {
        this.id = Objects.requireNonNull(id, "id");
        this.atlas = atlas;
        this.spriteName = spriteName;
        this.glyph = glyph;
        this.customImage = customImage;
    }

    public static Sprite ofAtlas(@NotNull String id, @NotNull String atlas, @NotNull String spriteName) {
        return new Sprite(id, atlas, spriteName, null, false);
    }

    public static Sprite ofGlyph(@NotNull String id, @NotNull String glyph) {
        return new Sprite(id, null, null, glyph, false);
    }

    public static Sprite ofCustomImage(@NotNull String id, @NotNull String glyph) {
        return new Sprite(id, null, null, glyph, true);
    }

    @NotNull
    public String id() {
        return id;
    }

    @Nullable
    public String atlas() {
        return atlas;
    }

    @Nullable
    public String spriteName() {
        return spriteName;
    }

    @Nullable
    public String glyph() {
        return glyph;
    }

    public boolean isCustomImage() {
        return customImage;
    }

    public boolean isAtlas() {
        return atlas != null && spriteName != null;
    }

    public boolean isGlyph() {
        return glyph != null && !glyph.isEmpty();
    }

    /**
     * Renders this sprite as an Adventure Component.
     * Atlas sprites use ObjectContents.sprite; glyphs fall back to a plain text component.
     */
    @NotNull
    public Component toComponent() {
        if (isAtlas()) {
            try {
                Key atlasKey = Key.key(atlas);
                Key spriteKey = Key.key(spriteName);
                SpriteObjectContents contents = ObjectContents.sprite(atlasKey, spriteKey);
                return Component.object(contents);
            } catch (Exception e) {
                // Fallback if keys are invalid
                return Component.text(glyph != null ? glyph : ":" + id + ":");
            }
        }
        if (isGlyph()) {
            return Component.text(glyph);
        }
        return Component.text(":" + id + ":");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Sprite sprite)) return false;
        return id.equals(sprite.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        return "Sprite{id='" + id + "', atlas=" + atlas + ", sprite=" + spriteName + ", glyph=" + glyph + "}";
    }
}
