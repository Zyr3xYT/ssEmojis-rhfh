package zyr3xyt.yml.ssemojis.resourcepack;

import zyr3xyt.yml.ssemojis.sprite.SpriteManager;
import net.kyori.adventure.resource.ResourcePackInfo;
import net.kyori.adventure.resource.ResourcePackRequest;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.net.URI;
import java.util.UUID;

/**
 * Sends configured resource packs to players.
 * Does not generate packs; administrators must host their own.
 */
public final class ResourcePackManager {

    private final SpriteManager spriteManager;

    public ResourcePackManager(@NotNull SpriteManager spriteManager) {
        this.spriteManager = spriteManager;
    }

    public void sendIfConfigured(@NotNull Player player) {
        ResourcePackSettings settings = spriteManager.resourcePackSettings();
        if (!settings.enabled() || settings.url().isBlank()) {
            return;
        }
        try {
            URI uri = URI.create(settings.url());
            ResourcePackInfo.Builder infoBuilder = ResourcePackInfo.resourcePackInfo()
                .uri(uri)
                .id(UUID.nameUUIDFromBytes(settings.url().getBytes()));

            if (!settings.sha1().isBlank()) {
                // Paper/Adventure accepts hash as string in newer APIs; keep simple
            }

            ResourcePackInfo info = infoBuilder.build();
            ResourcePackRequest request = ResourcePackRequest.resourcePackRequest()
                .packs(info)
                .required(settings.force())
                .prompt(Component.text(settings.prompt()))
                .build();

            player.sendResourcePacks(request);
        } catch (Exception e) {
            // Silent fail for individual players; log at plugin level if needed
        }
    }
}
