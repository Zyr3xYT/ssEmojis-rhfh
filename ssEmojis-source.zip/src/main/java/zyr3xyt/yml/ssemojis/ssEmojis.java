package zyr3xyt.yml.ssemojis;

import zyr3xyt.yml.ssemojis.api.ssEmoji;
import zyr3xyt.yml.ssemojis.command.ssEmojisCommand;
import zyr3xyt.yml.ssemojis.config.ConfigManager;
import zyr3xyt.yml.ssemojis.listener.PlayerJoinListener;
import zyr3xyt.yml.ssemojis.minimessage.SpriteTagResolver;
import zyr3xyt.yml.ssemojis.resourcepack.ResourcePackManager;
import zyr3xyt.yml.ssemojis.sprite.SpriteManager;
import zyr3xyt.yml.ssemojis.sprite.SpriteParser;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.minimessage.tag.resolver.TagResolver;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * ssEmojis — Shark Studios
 * Main plugin class.
 */
public final class ssEmojis extends JavaPlugin implements Listener {

    private SpriteManager spriteManager;
    private SpriteParser spriteParser;
    private ssEmoji api;
    private MiniMessage miniMessage;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        ConfigManager configManager = new ConfigManager(getDataFolder().toPath(), getLogger());
        spriteManager = new SpriteManager(configManager, getLogger());
        try {
            spriteManager.reload();
        } catch (Exception exception) {
            getLogger().severe("Unable to load ssEmojis configuration: " + exception.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        spriteParser = new SpriteParser(spriteManager);
        api = new ssEmoji(spriteManager, spriteParser);
        ResourcePackManager resourcePackManager = new ResourcePackManager(spriteManager);

        // MiniMessage with sprite tag support
        TagResolver spriteResolver = new SpriteTagResolver(spriteManager);
        miniMessage = MiniMessage.builder()
            .tags(TagResolver.resolver(TagResolver.standard(), spriteResolver))
            .build();

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(new PlayerJoinListener(resourcePackManager), this);

        PluginCommand command = getCommand("ssem");
        if (command == null) {
            getLogger().severe("The ssem command is missing from plugin.yml.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        ssEmojisCommand executor = new ssEmojisCommand(this, spriteManager);
        command.setExecutor(executor);
        command.setTabCompleter(executor);

        // Optional PlaceholderAPI
        if (getServer().getPluginManager().getPlugin("PlaceholderAPI") != null) {
            try {
                new zyr3xyt.yml.ssemojis.placeholder.ssEmojisExpansion(this, spriteManager).register();
                getLogger().info("PlaceholderAPI expansion registered.");
            } catch (Throwable t) {
                getLogger().warning("Could not register PlaceholderAPI expansion: " + t.getMessage());
            }
        }

        getLogger().info("ssEmojis enabled with " + spriteManager.getSprites().size() + " registered sprites.");
        getLogger().info("Developer: zyr3xyt.yml | Shark Studios");
    }

    @Override
    public void onDisable() {
        getLogger().info("ssEmojis disabled.");
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!spriteManager.registry().colonParserEnabled()) {
            return;
        }
        // Paper 1.21 AsyncChatEvent uses Adventure components.
        // We rewrite the message if shortcodes are present.
        Component original = event.message();
        String plain = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainText().serialize(original);
        if (!plain.contains(":")) {
            return;
        }
        Component parsed = spriteParser.parse(plain);
        // Preserve original style as much as possible by replacing only the content
        event.message(parsed);
    }

    public ssEmoji getAPI() {
        return api;
    }

    public SpriteManager getSpriteManager() {
        return spriteManager;
    }

    public MiniMessage getMiniMessage() {
        return miniMessage;
    }
}
