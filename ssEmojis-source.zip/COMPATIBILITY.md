# ssEmojis Compatibility Report

**Honest assessment — do not claim untested ranges.**

## Target of this build

| Component | Value |
|-----------|-------|
| Server API | Paper 1.21.9 (api-version 1.21) |
| Java | 21 |
| Primary rendering | Adventure `ObjectContents.sprite` (native atlas sprites) |
| Fallback | Private-use glyphs (require resource pack) |

## Supported (verified design)

- **Server**: Paper 1.21.x (and close forks that provide the same Adventure sprite API)
- **Client**: Modern clients that understand Adventure object components / sprite contents (1.20.5+ with appropriate protocol)

Vanilla Minecraft atlas sprites render without any resource pack on supported modern clients.

## Not supported by this JAR

- **Minecraft 1.8 – 1.19.x servers**  
  This artifact is compiled against Paper 1.21 API and uses Java 21 + modern Adventure APIs. It will not load on 1.8–1.19 servers.

- **Legacy font / resource-pack glyph system for 1.8–1.12**  
  No legacy `font.json` / bitmap provider generation is present.

- **Resource-pack-free arbitrary PNG images in scoreboards**  
  Minecraft scoreboard text is not an image canvas. Map-item pixel rendering, entity displays, or client-side mods would be required. None of those are implemented. Custom images are glyph-backed and therefore require a resource pack.

- **ViaVersion / ProtocolLib specific protocol rewriting**  
  Soft flags exist in config but no protocol rewriting code is present.

## Custom image system

- Images can be registered (config or API).
- They are stored as glyph-backed sprites.
- Clients must receive a resource pack that maps the Private Use Area character to the PNG.
- The plugin can prompt players to download a configured pack URL.
- The plugin does **not** generate or host the pack assets.

## Recommendation for true 1.8–modern support

A multi-module or multi-artifact approach would be required:

1. Modern module (this one) – Adventure sprites.
2. Legacy module – bitmap font providers + versioned resource packs.
3. Optional protocol bridge.

That work is outside the scope of the current single modern JAR.

## Tested in this environment

- Compilation against Paper API 1.21.9
- Basic unit-level logic (registry, parser, config loading) can be exercised offline
- No live Paper server or multi-version client matrix was available in the build environment

See `TEST-REPORT.md`.
